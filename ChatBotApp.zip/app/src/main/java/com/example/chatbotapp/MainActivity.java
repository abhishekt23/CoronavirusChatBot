package com.example.chatbotapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import static android.telephony.SmsManager.getDefault;
import static android.widget.Toast.makeText;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    BroadcastReceiver myReceiver;
    IntentFilter intentFilter1;
    SmsMessage[] smsMessages;
    Handler handler = new Handler();
    SmsManager smsManager = SmsManager.getDefault();
    static final int num = 1234;
    Runnable runnable;
    String answer;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.id_text_view);

        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS}, num);
        else if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS}, num);


            runnable = new Runnable()
            {
                @Override
                public void run() {
                    answer = "what it currently occurring at this very moment!?";
                    smsManager.sendTextMessage("5556", null, answer , null, null);
                }
            };

        myReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                    Bundle bundle = intent.getExtras();
                    Object[] pdus = (Object[]) bundle.get("pdus");
                    if (bundle != null) {
                        smsMessages = new SmsMessage[pdus.length];
                        for (int i = 0; i < pdus.length; i++) {
                            smsMessages[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                            Log.d("TAG", "onReceive: " + "Num: " + smsMessages[i].getOriginatingAddress() + ", Msg:" + smsMessages[i].getMessageBody());
                            Toast toast = Toast.makeText(MainActivity.this, "Num: " + smsMessages[i].getOriginatingAddress() + ", Msg:" + smsMessages[i].getMessageBody(), Toast.LENGTH_LONG);
                            toast.show();
                        }
                        handler.postDelayed(runnable, 1000);
                    }
            }
        };


    } //onCreate

    @Override
    protected void onResume() {
        super.onResume();
        intentFilter1 = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(myReceiver, intentFilter1);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(myReceiver);
    }
} //MainActivity
